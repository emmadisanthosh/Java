package com.tv.core;

/**
 * @author SEmmadi
 *
 */
class TV {
	
	public TV(){
		System.out.println("Constructor");
	}
	static {
		System.out.println("Static Bock");
	}
	public void method()
	{	System.out.println("Non Static");
	
	}
}
public class NonStaticConStruStaticBlock {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TV t= new TV();
		t.method();
	}

}

