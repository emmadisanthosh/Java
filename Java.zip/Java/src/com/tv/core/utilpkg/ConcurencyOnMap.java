package com.tv.core.utilpkg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author SEmmadi
 *
 */
public class ConcurencyOnMap {
	
	 public static void main(String[] args) {
		
		 //Map<String,String> map= new HashMap<String,String>();
		 Map<String,String> map= new ConcurrentHashMap<String,String>();
		 
		 map.put("fist","1");
		 map.put("se","2");
		 map.put("thr","3");
		 
		 Iterator<String> itr= map.keySet().iterator();
		 
		 while(itr.hasNext()){
			 System.out.println("value "+itr.next());
			 map.put("new", "newvalue");
		 }
		 
		 System.out.println(map);
		 
	}

}

