package com.tv.core.utilpkg;

/**
 * @author SEmmadi
 *
 */
class Parent{
	int x=10;
	public void show(){
		System.out.println("Parent Show");
	}
	public void onlyParent(){
		System.out.println("Only Parent");
	}
}
class Child extends Parent{
	int x=20;
	public void show(){
		System.out.println("Child Show"+super.x);
	}
	public void onlyChild(){
		System.out.println("Only Child");
	}
}
public class DownUpCasting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Parent p=new Parent();
		
		Parent pRef= new Child(); //UpCasting Parent Reference to Child Object it will automatically happen internally
		
		pRef.show();
		
		Child cRef= new Child();
		
		System.out.println(((Child)pRef).x);
		//Child c= new Parent(); //Shows Cannot convert Parent to Child error at compiletime not directly do downcast
		
		
		
		Child c= (Child) pRef;  //Create parent obj then use that variable for downcasting
		
		System.out.println("ParentRef With Instance Variable is different "+pRef.x);  //output 10
		
		/* Output 10 because variables in Java do not follow polymorphism and 
		 * overriding is only applicable to methods, not variables.*/
		
		System.out.println("COBject With DownCast"+c.x);
		
		pRef.show();
	
		//Accessing child variable from parent reference by type casting
		
		
	}

}

