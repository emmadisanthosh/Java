package com.tv.core.utilpkg;

import java.util.HashMap;
import java.util.Map;


/**
 * @author SEmmadi
 *
 */
public class HashMapInternal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String str1="FB";
		String str2="Ea";
		
		System.out.println("HashCode Str1:: "+str1.hashCode()+" HashCode Str2 "+str2.hashCode());
		Map<String,String> mapObject=new HashMap<String,String>();
		
		mapObject.put(str1, "value1");
		mapObject.put(str2, "value2");
		
	}

}

