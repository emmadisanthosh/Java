package com.tv.core.utilpkg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author SEmmadi
 *
 */
public class SynchronizeUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list= new ArrayList<String>();
		add(list);
 		
       Collections.synchronizedList(list);

	}

	public static void add(List<String> elements){
		System.out.println("Bydefault All List Elements Display In Insertion Order::");
		elements.add("TitleOrder");
		elements.add("Acris");
		elements.add("Orders");
		elements.add("UCC");
		elements.add("Orders");
		
	}
}

