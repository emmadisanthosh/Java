package com.tv.core.utilpkg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

/**
 * @author SEmmadi
 *
 */
public class ListT {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list= new ArrayList<String>(); //ArrayList not Synchrozied not thread safe
		//add(list);
		//show(list,"ArrayList::");
		
		
		//Todisplay sorting using List and reverse order use Collections
		
		List<String> elements= new ArrayList<String>(); //ArrayList not Synchrozied not thread safe
		
		elements.add("Acris");
		elements.add("Orders");
		elements.add("UCC");
		elements.add("Orders");
		elements.add("Orders2");
		
		Collections.sort(elements,Collections.reverseOrder());
		show(elements,"With Sorted ArrayList");
		
		
		List<String> linkList= new LinkedList<String>(); //LinkedList
		//Iterate List
		//add(linkList);
	    //show(linkList,"For Manipulation (insert and delete) and Peformance Use LinkedList::");
		
        Vector<String> vector= new Vector<String>();  //Vector 
        //Antho Way To Iterate Vector
        Enumeration<String> enm = vector.elements();
        while(enm.hasMoreElements()){
        	System.out.println("Another Way to Iterat:: "+enm.nextElement());
        }
        
        add(vector);
       // show(vector,"For Synchrozie and Size Increase use Vector");

	}


	public static void add(List<String> elements){
		System.out.println("Bydefault All List Elements Display In Insertion Order::");
		
		elements.add("Acris");
		elements.add("Orders");
		elements.add("UCC");
		elements.add("Orders");
		elements.add("Orders2");
		elements.add("TitleOrder");
		elements.set(4,"Index1Element"); //Adding element with Index Based
	}
	
	public static void show(List<String> elements,String name){
		System.out.println("========"+name+"==========");
		for(String result:elements){
			System.out.println(result);
	   }
		
	}
}

