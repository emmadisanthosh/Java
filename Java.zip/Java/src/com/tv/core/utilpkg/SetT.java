package com.tv.core.utilpkg;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * @author SEmmadi
 *
 */
public class SetT {
	
	public static void main(String[] args) {
		
		
		Set<String> hashSet = new HashSet<>();//(String.CASE_INSENSITIVE_ORDER);
		
		Set<String> linkedHS = new LinkedHashSet<>();//(String.CASE_INSENSITIVE_ORDER);
		
		
		Set<String> treeSet = new TreeSet<>();//(String.CASE_INSENSITIVE_ORDER);
		
		SortedSet<String> sortedSet = new TreeSet<>();//(String.CASE_INSENSITIVE_ORDER);
		
		//Synchronize Set
		Collections.synchronizedSet(hashSet);
		
		populate(hashSet);
		show(hashSet, "Without Dublicate and No Order Use HashSet");
		
		populate(linkedHS);
		show(linkedHS, "Without Duplicate and Insertion Order Use LinkedHashSet");
		
		populate(treeSet);  //By default it implements SortedSet and NavigableSet
		show(treeSet, "Without Duplicate and Sorted Order TreeSet");
		
		populate(sortedSet);
		show(sortedSet, "Without Duplicate and Sorted Order TreeSet");
		
		/*Set<String> copyA = new TreeSet<String>(a);
		show(copyA, "Copy of a");
		
		Set<String> copyB = new TreeSet<String>(b);
		show(copyB, "Copy of b");*/
	}

	static void populate(Set<String> s) {
		s.add("title");
		s.add("order");
		s.add("customer");
		s.add("uccform");
	}

	static void show(Set<String> s, String name) {
		System.out.println("============ " + name + " ==========");
		for (String t : s) {
			System.out.println(t);
		}
	}

}
