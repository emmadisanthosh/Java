package com.tv.core.utilpkg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author SEmmadi
 *
 */
public class MapT {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<String,String> map= new HashMap<String,String>();
		
		map.put("orderkey1", "ordervalue1");
		map.put("orderkey2", "ordervalue2");
		map.put("orderkey3", "ordervalue3");
		
		Iterator itr=map.entrySet().iterator();
		while(itr.hasNext()){
		Map.Entry<String, String> entry=(Map.Entry<String, String>)itr.next();
		System.out.println("Key::"+entry.getKey() +" Value:"+entry.getValue());
		}
		//Keys
		for(String keys:map.keySet()){
			System.out.println("Only Keys "+keys);
		}
	
	
		String ar[]= new String[5];
		for(int i=1;i<ar.length;i++){
			ar[i]="strArra"+i;
		}
		for(int j=1;j<ar.length;j++){
			System.out.println(ar[j]);
		}
	}

	
	
}

