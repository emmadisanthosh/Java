
package com.tv.core.utilpkg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author SEmmadi
 *
 */
public class CopyOnWriteArrayLis {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list= new ArrayList<Integer>();
		list.add(100);
		list.add(101);
		list.add(102);
		
		Iterator<Integer> itr=list.iterator();
		
		while(itr.hasNext()){
			Integer i= itr.next();
			//list.add(222);
			/*if(i==100){
				list.add(105);
				//itr.remove();
			}*/
		}
		
		
		//To Resolve ConcurrentModificationException use CopyOnWriteArrayList
		
		List<Integer> cpaList= new CopyOnWriteArrayList<Integer>();
		
		cpaList.add(100);
		cpaList.add(101);
		cpaList.add(102);
		
		Iterator<Integer> it= cpaList.iterator();
		while(it.hasNext()){
			Integer i= it.next();
			if(i==102)
			cpaList.add(103);
		}
		
		System.out.println("CopyOnArrayList"+cpaList);
	}

}

