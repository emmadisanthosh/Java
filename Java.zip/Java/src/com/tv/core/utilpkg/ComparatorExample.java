package com.tv.core.utilpkg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import com.tv.core.utilpkg.*;

class AgeComparator implements Comparator<Employee>{
	
	public int compare(Employee a1,Employee a2){
		//a1.getName().compareTo(a2.getName());
		return a1.getAge()-a2.getAge();
	}
}
public class ComparatorExample {
	 
 public static void main(String[] args) {
	
	 List<Employee> listemp= getEmployee();
	 
	 List<Employee> emplist= Arrays.asList(new Employee(12,"sdf",2323,"sdfsd"),
			 							new Employee(12,"sdf",2323,"sdfsd"));
	 System.out.println(emplist);
	 
	 System.out.println("Before Sort");
	 for(Employee e:listemp){
		 System.out.println(e);
	 }
	 //sort by age  if we write both it will show only one instead we can write own comparator class
	 
	/* Collections.sort(listemp, new Comparator<Employee>() {

		@Override
		public int compare(Employee o1, Employee o2) {
			// TODO Auto-generated method stub
			return o1.age-o2.age;
		}
	 
	 }); */

	 //OR
	 Collections.sort(listemp,new AgeComparator()); //No need to write again compare method anonymous imple
	/* System.out.println("After Sort Age");
	 for(Employee e:listemp){
		 System.out.println(e.getAge());
	 }*/
	 
	 //Sort By Name
	 Collections.sort(listemp,new Comparator<Employee>() {
		 public int compare(Employee e1,Employee e2){
			 return e1.name.compareTo(e2.name);
		 }
	 });
	/* System.out.println("After Sort Name");
	 for(Employee e:listemp){
		 System.out.println(e.getName());
	 }*/
	 
	 //another way1 using lamda
	 
	 listemp.sort((Employee e1,Employee e2)->e1.getAge()-e2.getAge());
	 for(Employee e:listemp){
		 System.out.println("AGeSort==="+e.getAge());
	 }
	 
	//another way2 using comparing method
	 
	 listemp.sort(Comparator.comparing(Employee::getAge));
	 for(Employee e:listemp){
		 System.out.println("AgeSort2"+e.getAge());
		 }
	
	 
	 listemp.sort(Comparator.comparing(Employee::getName));
	 for(Employee e:listemp){
		// System.out.println(e.getName());
	 }
	
	 //reverse order name
	 Comparator<Employee> compartor= Comparator.comparing(Employee::getName);
	 listemp.sort(compartor.reversed());
	 //System.out.println(listemp);
	 
	 
	 //Sort Mulitple Fields using then comparing
	 
	 Comparator<Employee> comp= Comparator.comparing(Employee::getAge).thenComparing(Employee::getName);
	 listemp.sort(comp);
	 System.out.println(listemp);
	 for(Employee e:listemp){
		 System.out.println(e.getAge()+" "+e.getName());
	 }
 }
	 
 public static List<Employee> getEmployee(){
		List<Employee> list= new ArrayList<Employee>();
		list.add(new Employee(20,"san",222,"bang"));
		list.add(new Employee(10,"kan",112,"kang"));
		list.add(new Employee(22,"aan",322,"mang"));
		list.add(new Employee(6,"zan",022,"aang"));
		return list;
	}

}
