package com.tv.core.utilpkg;

import java.util.ArrayList;
import java.util.List;

/**
 * @author SEmmadi
 *
 */
public class Employee {

	int age;
	String name;
	int salary;
	String location;

	public int getAge() {
		return age;
	}

	/**
	 * @param age
	 * @param name
	 * @param salary
	 * @param location
	 */
	public Employee(int age, String name, int salary, String location) {
		super();
		this.age = age;
		this.name = name;
		this.salary = salary;
		this.location = location;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public static List<Employee> getEmployeeList() {
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(90, "san", 10, "ban"));
		list.add(new Employee(85, "app", 43, "hyd"));
		list.add(new Employee(10, "zee", 33, "che"));
		list.add(new Employee(30, "cap", 9, "kal"));
		return list;
	}

	@Override
	public String toString() {
		return "Employee [age=" + age + ", name=" + name + ", salary=" + salary + ", location=" + location + "]";
	}

}
