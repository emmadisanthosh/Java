package com.tv.core;

/**
 * @author SEmmadi
 *
 */

final class TV1{
	
	private String ordername;

	/**
	 * @param ordername
	 */
	public TV1(){
		
	}
	public TV1(String ordername) {
		super();
		this.ordername = ordername;
	}

	public String getOrdername(String ordername){
		return this.ordername=ordername;
	}

	
	
}
class a extends TV1{
	
}

public class CustomImmutableClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TV1 t= new TV1();
		
	}

}

