package com.tv.core;

import java.util.Scanner;

/**
 * @author SEmmadi
 *
 */


class AmbException {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc= new Scanner(System.in);
		String str=sc.nextLine();
		String content=str.toLowerCase();
		int v=0,c=0,n=0,s=0;
		for(int i=0;i<content.length();++i){
			char ch=content.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'){
				++v;
			}else if(ch>='a'||ch<='z'){
				++c;
			} else {
				n++;
			}
		}
		System.out.println("Vow::"+v);
		System.out.println("con ::"+c);
		System.out.println("num ::"+n);
	}

}

