package com.tv.core.langpkg.am.outsidepkg;

import com.tv.core.langpkg.am.samepkg.AM;
import com.tv.core.utilpkg.SynchronizeUtil;

/**
 * @author SEmmadi
 *
 */
public class OutsidePkg extends AM {

	public static void main(String[] args) {
		
		OutsidePkg op= new OutsidePkg();
		AM am= new AM();
		 //System.out.println("i "+op.def_value); //Compilation for default value outside pkg
		  System.out.println("i "+op.protected_value); //Compilation error for default value outside pkg
		  System.out.println("i "+am.pub_value); //Without extend subclass for public out side pkg
		  
	}
}

