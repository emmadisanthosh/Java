package com.tv.core.langpkg.am.samepkg;

/**
 * @author SEmmadi
 *
 */
public class AM {

	/**
	 * @param args
	 */
	int def_value=10; //no access modifier
	protected int protected_value=10; //protected access modifier
	public int pub_value=10;
}

