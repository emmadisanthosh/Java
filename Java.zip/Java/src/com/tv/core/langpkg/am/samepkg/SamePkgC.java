package com.tv.core.langpkg.am.samepkg;



/**
 * @author SEmmadi
 *
 */
class SamePkgC  {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AM obj= new AM();
		System.out.println("i "+obj.def_value);  //no modifier or default value can access same pkg
		System.out.println("i "+obj.protected_value);  //protected modifier value can access same and outside pkg
	}

}

