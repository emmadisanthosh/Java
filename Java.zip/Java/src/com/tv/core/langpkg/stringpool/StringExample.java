package com.tv.core.langpkg.stringpool;

/**
 * @author SEmmadi
 *
 */
public class StringExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str1= new String("TitleVest");
		String str2= new String("TitleVest");
		if(str1==str2){
			System.out.println("Equals");
		}else{
			System.out.println("notEqualsstr");  //As its creating new object ref in heap memory
		}
		
		String strobj1="TitleVest";
		String strobj2="TitleVest";
		
		if(strobj1==strobj2){
			System.out.println("String Pool Equals");
		}else{
			System.out.println("String Pool notEquals");  //As its creating object in String Constant Pool (SCP) 
		}
		
		
	}

}

