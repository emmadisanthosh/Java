package com.tv.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author SEmmadi
 *
 */
public class ArrayListStringWithOddEven {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String ar[]={"5","2","4"};
		printEvenOddIndexes(ar);
		
		
	}

	
	public static void printEvenOddIndexes(String[] strings) {          
	    for (String word : strings) {

	        for (int i = 0; i < word.length(); i += 2) {
	            System.out.print(word.charAt(i));
	        }

	        System.out.print(" ");

	        for (int i = 1; i < word.length(); i += 2) {
	            System.out.print(word.charAt(i));
	        }

	        System.out.println();
	    }
	 }
}

