package com.tv.core;

/**
 * @author SEmmadi
 *
 */
public class ReportType {

	boolean implies(String var1) {
		return var1 == null ? false : true;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReportType rt= new ReportType();
	boolean result=	rt.implies(null);
	System.out.println(result);
	}

}

