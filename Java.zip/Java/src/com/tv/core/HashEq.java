package com.tv.core;

import java.util.HashSet;


/**
 * @author SEmmadi
 *
 */
public class HashEq {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("hash");
		

		TitleVest t1 = new TitleVest("titleorder");
		TitleVest t2 = new TitleVest("titleorder");

		System.out.println("HashCode1:::"+t1.hashCode());
		System.out.println("HashCode2:::"+t2.hashCode());
		
		HashSet<TitleVest> tvSet = new HashSet<TitleVest>();
		tvSet.add(t1);
		tvSet.add(t2);
		System.out.println("Size of the TitleOrder Object::" + tvSet.size());
		
		Integer i1 = new Integer(3);
		Integer i2 = new Integer(3);

		HashSet<Integer> tvSet1 = new HashSet<Integer>();
		tvSet1.add(i1);
		tvSet1.add(i2);
		System.out.println("Size of the Integer Object::" + tvSet1.size());
		
	}

}

class TitleVest {

	String orderType;

	public TitleVest(){
		
	}
	
	public TitleVest(String orderType) {
		super();
		this.orderType = orderType;
	}

	public String getOrderType() {
		return orderType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderType == null) ? 0 : orderType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TitleVest other = (TitleVest) obj;
		if (orderType == null) {
			if (other.orderType != null)
				return false;
		} else if (!orderType.equals(other.orderType))
			return false;
		return true;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}


}
