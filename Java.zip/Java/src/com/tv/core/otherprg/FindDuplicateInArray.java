package com.tv.core.otherprg;

/**
 * @author SEmmadi
 *
 */
public class FindDuplicateInArray {

	/**
	 * @param args
	 */
	
	 static void findRepeat(int arr[],int size){
		 int i,j;
		 //System.out.println("Repeating Elements::");
		 for( i=0;i<size;i++){
			  for(j=i+1;j<size;j++){
				  if(arr[i]==arr[j]){
					 // System.out.println(arr[i]+" ");
				  }
			  }
		 }
		 
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int arr[] = {2,4,6,2,7,8,6,2};
        System.out.println("length::"+arr.length);
        int arra[]={5,2,3,2,5,6};
        
        int size= arra.length;
        int k,j;
        for(k=0;k<size;k++){
         for(j=k+1;j<size;j++){
        	 if(arra[k]==arra[j]){
        		System.out.println("aaaa "+arra[k]+" ");
        	}
        }
        
        findRepeat(arr,arr.length);
	}

	}}

