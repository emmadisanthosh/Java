package com.tv.core.otherprg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author SEmmadi
 *
 */
public class FindDublicateList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	 List<String> list= new ArrayList<String>();
     list.add("titleroder");
     list.add("ucc");
     list.add("titleorder");
     list.add("acris");
     list.add("ucc");
    
	  
     Map<String,Integer> map= new HashMap<String,Integer>();
     
     for(String element:list){
    	 if(map.containsKey(element)){
    		 System.out.println("GET Element::"+map.get(element)+1);
    		 map.put(element, map.get(element)+1);
    	 } else{
    		 map.put(element, 1);
    	 }
     }
     
      map.forEach((k,v)->System.out.println("Element "+k+" "+v));
      
   /*   Iterator<Map.Entry<String,Integer>> mapItr= map.entrySet().iterator();
      
      while(mapItr.hasNext()){
    	  
    	  Map.Entry<String, Integer> mk=mapItr.next();
    	  
    	  
    	  
      }*/
      
     
     
	}

	
	
}

