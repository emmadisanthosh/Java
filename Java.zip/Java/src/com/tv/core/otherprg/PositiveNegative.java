package com.tv.core.otherprg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author SEmmadi
 *
 */
public class PositiveNegative {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer array[]= {-3,-45,-1,4,6,1,-2};
		
		List<Integer> list= Arrays.asList(array);
		List<Integer> l= new ArrayList<Integer>();
		List<Integer> positive= new ArrayList<Integer>();
		List<Integer> negative= new ArrayList<Integer>();
		for(int i=0;i<array.length;i++){
			
			int n=array[i];
			if(n>=0){
				l.add(n);
			}else if(n<=0){
				l.add(n);
			}
			
		}
		
		//one way
		list.stream().forEach(i -> (i < 0 ? negative : positive).add(i));
		System.out.println("negative "+negative);
		System.out.println("positive "+positive);
		
		//other way
		
		StringBuilder pos = new StringBuilder();
		StringBuilder neg = new StringBuilder();

		pos.append("Positive = ");
		neg.append("Negative = ");

		for (int i = 0; i < list.size(); i++) {
		    if (list.get(i) >= 0) {
		        pos.append(list.get(i) + ", ");
		    } else {
		        neg.append(list.get(i) + ", ");
		    }
		}
		
		pos.deleteCharAt(pos.length() - 2);
		neg.deleteCharAt(neg.length() - 2);
		
		System.out.println(pos.toString() + " and " + neg.toString());
		
		
		
		
	}

}

