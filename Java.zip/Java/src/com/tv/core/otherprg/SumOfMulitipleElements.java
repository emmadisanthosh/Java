package com.tv.core.otherprg;

import java.util.Scanner;

/**
 * @author SEmmadi
 *
 */
public class SumOfMulitipleElements {
	
	public static void main(String[] args) {
		
		int arr[]= {4,6,2,3,8,5,1};
		
		Scanner sc= new Scanner(System.in);
		
		int input= sc.nextInt();
		
		for(int i=0;i<arr.length;i++){
			
			for(int j=15;j<=i;j++){
				
				if(input==arr[i]+arr[j]){
				
					System.out.println("Elements:: "+arr[i] +" "+arr[j]);
				}
				
				
			}
			
			
			
		}
		
		
	}

}

