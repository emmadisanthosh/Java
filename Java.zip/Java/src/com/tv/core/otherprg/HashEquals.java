package com.tv.core.otherprg;

import java.util.HashSet;

/**
 * @author SEmmadi
 *
 */
public class HashEquals {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TitleVest t1= new TitleVest("titleorder");
		TitleVest t2= new TitleVest("titleorder");
		
		 HashSet<TitleVest> tvSet = new HashSet<TitleVest>();
	     tvSet.add(t1);
	     tvSet.add(t2);
	     System.out.println("Size of the TitleOrder::"+tvSet.size());
		Integer i1= new Integer(3);
		Integer i2= new Integer(3);
		
		
				
	}

}

class TitleVest {
	
	String orderType;

	public TitleVest(String orderType) {
		super();
		this.orderType = orderType;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	
}
