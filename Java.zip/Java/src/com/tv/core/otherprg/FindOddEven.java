package com.tv.core.otherprg;

import java.util.Scanner;

/**
 * @author SEmmadi
 *
 */
public class FindOddEven {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int num=new Scanner(System.in).nextInt();
      String n=new Scanner(System.in).next();
      System.out.println("enter str");
      System.out.println("n "+n);
      if(num%2==0){
    	  System.out.println("even");
      }
      else{
    	System.out.println();  
      }
	}

}

