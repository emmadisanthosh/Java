package com.tv.core.otherprg;

import java.util.Scanner;

/**
 * @author SEmmadi
 *
 */
public class FiboEx {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=new Scanner(System.in).nextInt();
		genFib(number);
		
	}
	
	public static void genFib(int n){
		int first=0,second=1;
        System.out.print(first+","+second);		
		for(int i=0;i<=n;i++){
		
			int next=first+second;
			System.out.print(","+next);
			first=second;
			second=next;
			
		}
	}

}