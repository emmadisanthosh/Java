package com.tv.core.otherprg;

import java.util.*;
/**
 * @author semmadi-a
 *
 */
public class FindMaxElement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list= new ArrayList<String>();
		list.add("12");
		list.add("35");
		list.add("2");
		System.out.println("Max: "+Collections.max(list));
		
	}

}

