package com.tv.core.otherprg;

import java.util.Scanner;

/**
 * @author SEmmadi
 *
 */
public class WithOutTempSwap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
	  //With Temp/Third Variable Swap
		
      int firstnum=new Scanner(System.in).nextInt();
      int secondnum=new Scanner(System.in).nextInt();
      int temp;
      System.out.println("Before Swap:: " + "First Num "+firstnum+" Second Num "+secondnum);
      
      temp=firstnum;
      firstnum=secondnum;
      secondnum=temp;
      
      System.out.println("After Swap:: " + "First Num "+firstnum+" Second Num "+secondnum);
      
      //Without Temp/Third Variable Swap  
      
      int first=10,second=20;
      
      System.out.println("Before Swap:: " + "First Value "+first+" Second Value "+second);
      
      first =first+second; //10+20=30
      second=first-second; //30-20=10
      first=first-second;  //30-10=20
      
      System.out.println("After Swap:: " + "First Value "+first+" Second Value "+second);
      
      
      
	}

}

