package com.tv.core.otherprg;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * @author SEmmadi
 *
 */
public class RemoveVowel {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//String str = "GeeeksforGeeks - A Computer Science Portal for Geeks";
        //System.out.println(remVowel(str));
		
		Scanner input = new Scanner(System.in);
		
		String str=input.nextLine();
		String res=str.replaceAll("[aeiouAEIOU]", "");
		System.out.println("result::"+res);
		
	}

	/*static String remVowel(String str)
    {
         Character vowels[] = {'a', 'e', 'i', 'o', 'u','A','E','I','O','U'};
          
         List<Character> al = Arrays.asList(vowels);
         
         
         StringBuffer sb = new StringBuffer(str);
          
         for (int i = 0; i < sb.length(); i++) {
             
             if(al.contains(sb.charAt(i))){
                sb.replace(i, i+1, "") ;
                i--;
             }
        }
          
         
        return sb.toString();
    }*/
	
}

