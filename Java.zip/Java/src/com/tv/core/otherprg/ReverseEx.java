package com.tv.core.otherprg;

/**
 * @author SEmmadi
 *
 */
public class ReverseEx {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
	 int num=123,reverse=0;
	 
	 int nu=412,rev=0;
	 
	 while(nu!=0){
		 
		 int dig=nu%10;
		 nu=nu*10+dig;
		 nu=nu/10;
	 }
	 System.out.println("nujujujuu "+nu);
	 while(num!=0){
		int digit=num%10; //12
		System.out.println("Digit "+digit);
		reverse=reverse*10+digit;
		System.out.println("Reverse:: "+reverse);
		num=num/10;
		System.out.println("num"+num);
	 }
    
	 System.out.println("Reverse Number :: "+reverse);
	 
	}

}

