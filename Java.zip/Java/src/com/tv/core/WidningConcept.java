package com.tv.core;

/**
 * @author SEmmadi
 *
 */
class Binding {
	public int sum(int a,int b){
		System.out.println("Primitive");
		return a+b;
	}
	public int sum(Integer a,Integer b){
		System.out.println("Object");
		return a+b;
	}
}
public class WidningConcept {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Binding b= new Binding();
		b.sum(10, 40);
		int a1=10;
		Integer b1=30;
		//b.sum(a1,b1); //One int and Intger if we pass Ambiguous error will come
	}

}

