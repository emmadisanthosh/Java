package com.tv.core.exception;

/**
 * @author SEmmadi
 *
 */
public class CompExceptionCheck {

	/**
	 * @param args
	 */
	public static void main(String[] args)  {

		String str="10";
		int i= Integer.valueOf(str);
		
		int ival=10;
		
		String val= String.valueOf(ival);
		System.out.println("int to str"+val);
		
	}

}

