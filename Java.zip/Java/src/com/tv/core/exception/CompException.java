package com.tv.core.exception;

/**
 * @author SEmmadi
 *
 */
public class CompException extends Exception {
  
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CompException(String msg){
		super(msg);
	}
	
}

