package com.tv.core;

/**
 * @author SEmmadi
 *
 */
class DominoLender {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String lenderName="Test Name.LLC";
		int len=lenderName.length();
		System.out.println("Length:: "+len);
		String result=lenderName.substring(len-3, len);
		System.out.println("result:: "+result);

	}

}

