package com.tv.core;

/**
 * @author SEmmadi
 *
 */
public class FirstLetterCapString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="titlevest project and aws";
		 String words[]=str.split("\\s");  
		    String capitalizeWord="";  
		    for(String w:words){  
		        String first=w.substring(0,1);  
		        String afterfirst=w.substring(1);  
		        capitalizeWord+=first.toUpperCase()+afterfirst+" ";  
		    }  
		    System.out.println("Result:: "+capitalizeWord);

	}

}

