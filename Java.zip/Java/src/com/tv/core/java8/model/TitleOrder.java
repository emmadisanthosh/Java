package com.tv.core.java8.model;

/**
 * @author SEmmadi
 *
 */
public class TitleOrder implements Comparable<TitleOrder>{
	
	/**
	 * @param orderNumber
	 * @param orderType
	 */
	public TitleOrder(int orderNumber,String orderType) {
		super();
		this.orderNumber = orderNumber;
		this.orderType = orderType;
	}
	private int orderNumber;
	private String orderType;
	
	public int getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	@Override
	public String toString() {
		return "TitleOrder [orderNumber=" + orderNumber + ", orderType=" + orderType + "]";
	}
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(TitleOrder o) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}

