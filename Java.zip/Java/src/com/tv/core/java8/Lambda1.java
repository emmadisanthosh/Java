package com.tv.core.java8;

import com.tv.core.utilpkg.SynchronizeUtil;

/**
 * @author SEmmadi
 *
 */
public class Lambda1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ITitlerOder it=(titlevest)->{
			System.out.println("method");
		};
		it.orderDetails("result");
	  
		
		ITV ref= (itv)->{
			System.out.println("ITV Method");
		};
		ref.orderType("OrderTypeCall");
	}
	
 
}
interface ITitlerOder{
	public void orderDetails(String result);
}

interface ITV{
	public void orderType(String type);
}