package com.tv.core.java8;

import java.io.IOException;

/**
 * @author SEmmadi
 *
 */

public class ExcepTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}

