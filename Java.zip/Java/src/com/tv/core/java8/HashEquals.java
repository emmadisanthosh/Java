package com.tv.core.java8;

import java.util.HashSet;

/**
 * @author SEmmadi
 *
 */
public class HashEquals {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TitleVest t1 = new TitleVest("titleorder");
		TitleVest t2 = new TitleVest("titleorder");

		
		HashSet<TitleVest> tvSet = new HashSet<TitleVest>();
		tvSet.add(t1);
		tvSet.add(t2);
		System.out.println("Size of the TitleOrder WithOut Wrapper::" + tvSet.size());
		
		Integer i1 = new Integer(3);
		Integer i2 = new Integer(3);
		HashSet<Integer> tvWrapper = new HashSet<Integer>();
		tvWrapper.add(i1);
		tvWrapper.add(i2);
		System.out.println("Size of the TitleOrder With Wrapper::" + tvWrapper.size());
		
	}

}

class TitleVest {

	String orderType;

	public TitleVest(String orderType) {
		super();
		this.orderType = orderType;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderType == null) ? 0 : orderType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TitleVest other = (TitleVest) obj;
		if (orderType == null) {
			if (other.orderType != null)
				return false;
		} else if (!orderType.equals(other.orderType))
			return false;
		return true;
	}
	
	

}
