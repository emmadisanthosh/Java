package com.tv.core.java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.tv.core.java8.model.TitleOrder;
import java.util.Comparator;	

/**
 * @author SEmmadi
 *
 */
public class ComparatorTO {

	public static void main(String[] args) {
		
	
	List<TitleOrder> list=Arrays.asList(
			new TitleOrder(32,"UCC"),
			new TitleOrder(12,"Title"),
			new TitleOrder(2,"Acris"),
			new TitleOrder(55,"Other"),
			new TitleOrder(5,"Coop")
			);
	
	
	
	
	    //Sort Using Lamda one way
		/*Collections.sort(list, new Comparator<TitleOrder>() {

			public int compare(TitleOrder t1, TitleOrder t2) {

				//return t1.getOrderType().compareTo(t2.getOrderType());
				return t1.getOrderNumber()- t2.getOrderNumber();
			}
	

		});
		for (TitleOrder li : list) {
			//if(li.getOrderType().startsWith("C"))
			System.out.println("Data:: " + li.getOrderNumber());
*/		
		 //Sort Using Lamda anthoer way
			
		/*list.sort((TitleOrder o1, TitleOrder o2)->o1.getOrderNumber()-o2.getOrderNumber());
		list.sort((TitleOrder o1, TitleOrder o2)->o1.getOrderType().compareTo(o2.getOrderType()));
		
		for(TitleOrder t:list){
			System.out.println("With Lamda Order Type "+t.getOrderType());
			System.out.println("With Lamda Order Number"+t.getOrderNumber());
		}*/
		
		//list.forEach((results)->System.out.println(results.getOrderNumber()));
	    
	   //Comparator<TitleOrder> toComparator= Comparator.comparing(TitleOrder::getOrderNumber);
	 
	 
		
		Collections.sort(list,(a,b)->a.getOrderNumber()-b.getOrderNumber());
		Collections.sort(list,(c,d)->c.getOrderType().compareTo(d.getOrderType()));
		
		
		list.forEach((results)->System.out.println(results.getOrderNumber()));
		
	    Collections.sort(list, (t1,t2)->t1.getOrderNumber()- t2.getOrderNumber());
	    list.forEach((results)->System.out.println(results.getOrderNumber()));
	    
	    Collections.sort(list, (t1,t2)->t1.getOrderType().compareTo(t2.getOrderType()));		
	    list.forEach((results)->System.out.println(results.getOrderType()));
	    
	   
	}
		
}
	

