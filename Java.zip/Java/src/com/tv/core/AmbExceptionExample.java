package com.tv.core;

/**
 * @author SEmmadi
 *
 */

//And the widen order for char is:
//char -> int -> long -> float -> double

class Details {
	
	public void method(Object o){
		System.out.println("Details Object");
	}
	/*public void method(StringBuffer o){
		System.out.println("Details strbuff");
	}*/
	public void method(String s){
		System.out.println("Details str");
	}
	
	public void test(String obj1, Object obj2) {
		System.out.println("B");
	}

	public void test(Object obj1, String obj2) {
		System.out.println("C");
	}
	
}
public class AmbExceptionExample {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Details d= new Details();
		//d.method(null); //String method will call instead of Object
		//d.method(null);
		//d.test(null,null); //Compilation error
	}

}

