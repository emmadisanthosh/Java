package com.tv.test;

/**
 * @author SEmmadi
 *
 */

class B {
	private int i;

	public B(int i) {
		this.i = i;
	}

	public int getInt() {
		return i;
	}
}

class C {
	public B b;

	C(int i) {
	}

	public B getB() {
		return b;
	}
}

class D {
	public static String f1(B b) {
		return "f1B";
	}

	public static String f1(int b) {
		return "f1int";
	}

	public static String f2() {
		System.out.println("f2 called");
		C c = new C(42);
		return D.f1(c.getB());
	}
}

public class Test1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// D d= new D();
		D.f2();
	}

}
