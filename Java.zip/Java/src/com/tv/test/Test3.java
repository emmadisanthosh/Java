
package com.tv.test;

import java.awt.*;

public class Test3 {

	public static void main(String[] args) {

		try {
            
            System.out.println("A");
            Thread.sleep(200);
            System.out.println("BB");
        } 
        catch (Exception ie) { }
	}
}