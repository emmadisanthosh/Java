/*package com.tv;

*//**
 * @author SEmmadi
 *
 *//*


import org.apache.log4j.Logger;

public class SFTPClient
{
  static Logger logger = Logger.getLogger("bw.logger");
  

  public SFTPClient() {}
  
  public static SFTPConnection connectsWithUserPassword(String hostname, int port, String username, String password, int timeout)
    throws SFTPException
  {
    logger.info("Enter connectsWithUserPassword...");
    SFTPConnConfig config = SFTPConnConfig.createConfig(hostname, port, username, password, timeout);
    SFTPConnection sftpConn = new SFTPConnection(config);
    sftpConn.connect();
    logger.info("Leave connectsWithUserPassword().");
    return sftpConn;
  }
  
  public static SFTPConnection connectsWithPublicKey(String hostname, int port, String username, String privateKeyFilename, String passpharse, int timeout)
    throws SFTPException
  {
    logger.info("Enter connectsWithPublicKey...");
    SFTPConnConfig config = SFTPConnConfig.createConfig(hostname, port, username, 
      privateKeyFilename, passpharse, timeout);
    SFTPConnection sftpConn = new SFTPConnection(config);
    sftpConn.connect();
    logger.info("Leave connectsWithPublicKey()");
    return sftpConn;
  }
  


  public static SFTPConnection connectsWithUserPasswordAndProxy(String hostname, int port, String username, String password, String proxyHostname, int porxyPort, String proxyUsername, String proxyPassword, int timeout)
    throws SFTPException
  {
    logger.info("Enter connectsWithUserPasswordAndProxy...");
    SFTPConnConfig config = SFTPConnConfig.createConfig(hostname, port, username, password, 
      proxyHostname, porxyPort, proxyUsername, proxyPassword, timeout);
    SFTPConnection sftpConn = new SFTPConnection(config);
    sftpConn.connect();
    logger.info("Leave connectsWithUserPasswordAndProxy().");
    return sftpConn;
  }
  

  public static SFTPConnection connectsWithPublicKeyAndProxy(String hostname, int port, String username, String privateKeyFilename, String passpharse, String proxyHostname, int porxyPort, String proxyUsername, String proxyPassword, int timeout)
    throws SFTPException
  {
    logger.info("Enter connectsWithPublicKeyAndProxy...");
    SFTPConnConfig config = SFTPConnConfig.createConfig(hostname, port, username, privateKeyFilename, passpharse, 
      proxyHostname, porxyPort, proxyUsername, proxyPassword, timeout);
    SFTPConnection sftpConn = new SFTPConnection(config);
    sftpConn.connect();
    logger.info("Leave connectsWithPublicKeyAndProxy().");
    return sftpConn;
  }
  

  public static SFTPConnection connect(String hostname, int port, String username, String password, String usernameWithKey, String privateKeyFilename, String passpharse, String proxyHostname, int porxyPort, String proxyUsername, String proxyPassword, int timeout)
    throws SFTPException
  {
    logger.info("Enter connect ...");
    boolean isSimpleAuthentication = true;
    if ((privateKeyFilename != null) && (!privateKeyFilename.trim().equals(""))) {
      isSimpleAuthentication = false;
    }
    
    boolean hasProxy = false;
    if ((proxyHostname != null) && (!proxyHostname.trim().equals(""))) {
      hasProxy = true;
    }
    
    if (isSimpleAuthentication) {
      if (hasProxy) {
        return connectsWithUserPasswordAndProxy(hostname, port, username, password, 
          proxyHostname, porxyPort, proxyUsername, proxyPassword, timeout);
      }
      return connectsWithUserPassword(hostname, port, username, password, timeout);
    }
    
    if (hasProxy) {
      return connectsWithPublicKeyAndProxy(hostname, port, usernameWithKey, privateKeyFilename, passpharse, 
        proxyHostname, porxyPort, proxyUsername, proxyPassword, timeout);
    }
    return connectsWithPublicKey(hostname, port, username, privateKeyFilename, passpharse, timeout);
  }
  


  private TransferModeType getModeType(String transferMode)
    throws SFTPException
  {
    if ("AUTO".equalsIgnoreCase(transferMode)) {
      return TransferModeType.AUTO_TYPE;
    }
    if ("ASCII".equalsIgnoreCase(transferMode)) {
      return TransferModeType.ASCII_TYPE;
    }
    if ("BINARY".equalsIgnoreCase(transferMode)) {
      return TransferModeType.BINARY_TYPE;
    }
    throw new SFTPException("Invalid Transfer Mode");
  }
  
  public void get(SFTPConnection conn, String remoteDirectory, String remoteFileName, String localDirectory, String localFileName, String transferMode) throws SFTPException
  {
    get(conn, remoteDirectory, remoteFileName, localDirectory, localFileName, transferMode, false);
  }
  
  public void get(SFTPConnection conn, String remoteDirectory, String remoteFileName, String localDirectory, String localFileName, String transferMode, boolean keepConnectionAlive)
    throws SFTPException
  {
    logger.info("Enter get...");
    TransferModeType transferModeType = getModeType(transferMode);
    GetCmd cmd = new GetCmd(remoteDirectory, remoteFileName, localDirectory, localFileName, transferModeType);
    if (!conn.isConnected()) conn.connect();
    cmd.execute(conn);
    if (keepConnectionAlive) {
      conn.resetToHomeDir();
    } else {
      conn.disconnect();
    }
    logger.info("Leave Get().");
  }
  
  public String[] getFileNamesSortedByTimestamp(SFTPConnection conn, String remoteDirectory, String fileFilter, boolean keepConnectionAlive) throws SFTPException {
    logger.info("Enter getFileNamesSortedByTimestamp...");
    GetDirectoryCmd cmd = new GetDirectoryCmd(remoteDirectory, fileFilter, null);
    if (!conn.isConnected()) conn.connect();
    String[] fileNames = cmd.getFileNamesSortedByTimestamp(conn);
    if (keepConnectionAlive) {
      conn.resetToHomeDir();
    } else {
      conn.disconnect();
    }
    logger.info("Leave getFileNamesSortedByTimestamp() returned with " + fileNames.length + " file names.");
    return fileNames;
  }
  
  public void put(SFTPConnection conn, String localData, String localDirectory, String localFileName, String remoteDirectory, String remoteFileName, boolean append, String transferMode)
    throws SFTPException
  {
    if ((localFileName == null) || (localFileName.trim().equals(""))) {
      put(conn, localData, remoteDirectory, remoteFileName, append, transferMode, false);
    } else {
      put(conn, localDirectory, localFileName, remoteDirectory, remoteFileName, append, transferMode, false);
    }
  }
  
  public void put(SFTPConnection conn, String localDirectory, String localFileName, String remoteDirectory, String remoteFileName, boolean append, String transferMode) throws SFTPException
  {
    put(conn, localDirectory, localFileName, remoteDirectory, remoteFileName, append, transferMode, false);
  }
  
  public void put(SFTPConnection conn, String localDirectory, String localFileName, String remoteDirectory, String remoteFileName, boolean append, String transferMode, boolean keepConnectionAlive)
    throws SFTPException
  {
    logger.info("Enter put local file...");
    TransferModeType transferModeType = getModeType(transferMode);
    InputData inputData = new InputData(localDirectory, localFileName);
    PutCmd cmd = new PutCmd(inputData, remoteDirectory, remoteFileName, append, transferModeType);
    if (!conn.isConnected()) conn.connect();
    cmd.execute(conn);
    if (keepConnectionAlive) {
      conn.resetToHomeDir();
    } else {
      conn.disconnect();
    }
    logger.info("Leave Put().");
  }
  
  public void put(SFTPConnection conn, String localData, String remoteDirectory, String remoteFileName, boolean append, String transferMode) throws SFTPException
  {
    put(conn, localData, remoteDirectory, remoteFileName, append, transferMode, false);
  }
  
  public void put(SFTPConnection conn, String localData, String remoteDirectory, String remoteFileName, boolean append, String transferMode, boolean keepConnectionAlive)
    throws SFTPException
  {
    logger.info("Enter put localData...");
    TransferModeType transferModeType = getModeType(transferMode);
    InputData inputData = new InputData(localData);
    PutCmd cmd = new PutCmd(inputData, remoteDirectory, remoteFileName, append, transferModeType);
    if (!conn.isConnected()) conn.connect();
    cmd.execute(conn);
    if (keepConnectionAlive) {
      conn.resetToHomeDir();
    } else {
      conn.disconnect();
    }
    logger.info("Leave Put().");
  }
  
  public void deleteFile(SFTPConnection conn, String remoteDirectory, String remoteFileName) throws SFTPException {
    deleteFile(conn, remoteDirectory, remoteFileName, false);
  }
  
  public void deleteFile(SFTPConnection conn, String remoteDirectory, String remoteFileName, boolean keepConnectionAlive)
    throws SFTPException
  {
    logger.info("Enter deleteFile...");
    DeleteFileCmd cmd = new DeleteFileCmd(remoteDirectory, remoteFileName);
    if (!conn.isConnected()) conn.connect();
    cmd.execute(conn);
    if (keepConnectionAlive) {
      conn.resetToHomeDir();
    } else {
      conn.disconnect();
    }
    logger.info("Leave deleteFile().");
  }
  
  public void renameFile(SFTPConnection conn, String remoteDirectory, String remoteFileName, String newFileName) throws SFTPException {
    renameFile(conn, remoteDirectory, remoteFileName, newFileName, false);
  }
  
  public void renameFile(SFTPConnection conn, String remoteDirectory, String remoteFileName, String newFileName, boolean keepConnectionAlive)
    throws SFTPException
  {
    logger.info("Enter renameFile...");
    RenameFileCmd cmd = new RenameFileCmd(remoteDirectory, remoteFileName, newFileName);
    if (!conn.isConnected()) conn.connect();
    cmd.execute(conn);
    if (keepConnectionAlive) {
      conn.resetToHomeDir();
    } else {
      conn.disconnect();
    }
    logger.info("Leave renameFile().");
  }
  
  public static void disconnect(SFTPConnection conn) {
    boolean disconnectedNow = true;
    for (int i = 0; i < 3; i++) {
      try {
        conn.disconnect();
        disconnectedNow = true;
      } catch (Exception e) {
        disconnectedNow = false;
      }
    }
    if (!disconnectedNow) {
      try {
        Thread.sleep(5000L);
        conn.disconnect();
      } catch (Exception e) {
        logger.warn("Failed to disconnect from FTP Server after 4 attempts to disconnect");
      }
    }
  }
}
*/