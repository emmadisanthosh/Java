package com.tv;

import java.util.Hashtable;

import com.jcraft.jsch.*;
/**
 * @author SEmmadi
 *
 */
public class ConnectionTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws SftpException {
		// TODO Auto-generated method stub
		
		    JSch jsch = new JSch();
	        Session session = null;
	        try {
	        	Hashtable<String, String> ht= new Hashtable<String,String>();
	        	ht.put("ssh-rsa 2048 a7:55:da:38:08:85:55:24:54:38:0c:54:a1:3d:ec:fe", "no");
	        	 //ht.put("StrictHostKeyChecking","no");
	        	 
	            /*session = jsch.getSession("fatic22641", "uatftp.sircon.com", 22);
	             session.setConfig("ssh-rsa 2048 a7:55:da:38:08:85:55:24:54:38:0c:54:a1:3d:ec:fe", "no");
	            session.setConfig(ht);
	            session.setPassword("8NcEVND6eng4");
	            session.connect();
	            Channel channel = session.openChannel("sftp");
	            channel.connect();
	            ChannelSftp sftpChannel = (ChannelSftp) channel;
	            sftpChannel.get("remotefile.txt", "localfile.txt");
	            sftpChannel.exit();
	            session.disconnect();*/
	            /*
	            FileSystemOptions fsOptions = new FileSystemOptions();
	            SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(fsOptions, "no");
	            FileSystemManager fsManager = VFS.getManager();
	            String uri = "sftp://user:password@host:port/absolute-path";
	            FileObject fo = fsManager.resolveFile(uri, fsOptions);
	            */
	            
	            
	            session = jsch.getSession("fatic22641","uatftp.sircon.com",22);
	            
	            session.setPassword("8NcEVND6eng4");
	            
	            
	            //session.setConfig(ht);
	            
	            System.out.println("Establishing Connection...");
	            session.connect();
	                System.out.println("Connection established.");
	            System.out.println("Creating SFTP Channel.");
	            ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
	            sftpChannel.connect();
	            System.out.println("SFTP Channel created.");
	            
	        } catch (JSchException e) {
	            e.printStackTrace();  
	        }

	}

}

