package com;


/**
 * @author SEmmadi
 *
 */
public class CheckCase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String prp="ucc order test";
		String result=toCamelCase(prp);
		System.out.println("Result ::"+result);
		
		String camCase="title order use case test";
		String convertObj=convertToCamelCase(camCase);
		System.out.println("Converted :: "+convertObj);

	}

	
	public static String toCamelCase(String inputString) {
	       String result = "";
	       if (inputString.length() == 0) {
	           return result;
	       }
	       char firstChar = inputString.charAt(0);
	       char firstCharToUpperCase = Character.toUpperCase(firstChar);
	       result = result + firstCharToUpperCase;
	       for (int i = 1; i < inputString.length(); i++) {
	           char currentChar = inputString.charAt(i);
	           char previousChar = inputString.charAt(i - 1);
	           if (previousChar == ' ') {
	               char currentCharToUpperCase = Character.toUpperCase(currentChar);
	               result = result + currentCharToUpperCase;
	           } else {
	               char currentCharToLowerCase = Character.toLowerCase(currentChar);
	               result = result + currentCharToLowerCase;
	           }
	       }
	       return result;
	   }

	
	public static String convertToCamelCase(String str) {
	    if (str == null)
	        return null;
	    StringBuilder ret = new StringBuilder(str.length());
	    for (String word : str.split(" ")) {
	        if (!word.isEmpty()) {
	            ret.append(Character.toUpperCase(word.charAt(0)));
	            ret.append(word.substring(1).toLowerCase());
	        }
	        if (!(ret.length() == str.length()))
	            ret.append(" ");
	    }
	    //System.out.println("Covert To CamelCase:: "+ret.toString());
	    return ret.toString();
	}
	
}

