import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * @author SEmmadi
 *
 */
public class ReadML {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
         
		/* Scanner scanner= new Scanner(System.in);
         String[] tokens = scanner.nextLine().split("\\s");
		 System.out.println(Arrays.toString(tokens));*/
		
		/*Scanner scanner = new Scanner(System.in);
		
		while (scanner.hasNextLine()) {
			List<String> tokens = new ArrayList<>();
			Scanner lineScanner = new Scanner(scanner.nextLine());

			while (lineScanner.hasNext()) {
				tokens.add(lineScanner.next());
			}

			lineScanner.close();
			System.out.println(tokens);
		}

		scanner.close();*/
		System.out.println("Enter Order Types");
		Scanner scanner = new Scanner(System.in);
		
		
		//Scanner scint = new Scanner(System.in);
		List<Integer> list = new ArrayList<Integer>();
		String[] tokens = scanner.nextLine().split("\\s");
		System.out.println(Arrays.toString(tokens));
		for(String token:tokens){
			System.out.println("Tokens::"+token);
		}
		/*while (scint.hasNextInt())
		  list.add(scint.nextInt());
		for(Integer i:list){
			System.out.println("Numof Order::"+i);
		}*/
		
		/*System.out.println("Enter Order Type");
		String name = scanner.nextLine(); 
		System.out.println("orders: ");
		int orders = scanner. nextInt(); // it's an integer.
		System.out.println("orders");
		*/  

	}

}

