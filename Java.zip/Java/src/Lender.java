import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
/**
 * @author SEmmadi
 *
 */
public class Lender {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		 * String lenderName = null; int lenderLength =
		 * columnValues.get(0).toString().length(); if (lender.contains("Llc"))
		 * { lenderName = lender.substring(lender.length() - 3, lenderLength);
		 * int lenderSize = lender.length() - 3; map.put("lname",
		 * lender.substring(0, lenderSize) + lenderName.toUpperCase());
		 * 
		 * } else { map.put("lname", columnValues.get(0).toString()); }
		 */
		/*String str="Silvermine Ventures, Llc D/B/A Thoroughbred MortgAGE";
		String lender="Mortgage LLC";
		
		System.out.println("Index: "+lender.split(" "));
		
		if(str.contains("Llc")){
			System.out.println("LLC"+str.replace("Llc", "LLC"));
		}
		for(int i=0;i<lender.length();i++){
			System.out.println("lender::"+lender.substring(i, i + 1));
	    
		String otherLetters = lender.substring(0, i) + lender.substring(i + 1);
		System.out.println("OL::"+otherLetters);
		}
	
		
		String orderNumber="FANY43146";
		System.out.println("indexof::::"+orderNumber.indexOf("A"));
		String subStr1=orderNumber.substring(0, 2);
		String subStr2=orderNumber.substring(2, 4);
		String subStr3=orderNumber.substring(4, 9);
		System.out.println("index1 ::"+subStr1 +"index2 "+subStr2+"subStr3 "+subStr3);
		String fastFileno=subStr1+"-"+subStr2+"-"+subStr3;
		System.out.println("FastFileNo ::"+fastFileno);
		
		StringBuffer sb= new StringBuffer();
		sb.append("FieldName");
		sb.append("|");
		sb.append("OldValue");
		sb.append("|");
		sb.append("NewValue");
		sb.append("~");
		sb.append("FieldName1");
		sb.append("|");
		sb.append("OldValue1");
		sb.append("|");
		sb.append("NewValue1");
		sb.append("~");
		
		System.out.println("Length:: "+sb.length());
		if(!"".equals(sb)) {
		    System.out.println("Changes : " + sb);
		    //logDoc.replaceItemValue("Details", sb);
		} else {
		    System.out.println("No Changes");
		}*/
		
		Map<String,String> oldMap = new HashMap<String,String>();
		oldMap.put("key1","value1");
		oldMap.put("key2","value2");
		oldMap.put("key3","value31");
		
		Map<String,String> newMap = new HashMap<String,String>();
		newMap.put("key1","value1");
		newMap.put("key2","value2");
		newMap.put("key3","value3");
		
		StringBuffer sb= new StringBuffer();
		int count=0;
		for (String key : oldMap.keySet()) {
			//System.out.println("Key :: "+key+" Old Value: " + oldMap.get(key)+" New Value: " + newMap.get(key));
			
			
			if (!oldMap.get(key).equals(newMap.get(key))) {
				
				System.out.println("equals");
				
				if(count!=0){
					
					sb.append("~");
					sb.append(key);
					sb.append("|");
					sb.append(oldMap.get(key));
					sb.append("|");
					sb.append(newMap.get(key));
					sb.append("~ ");
					
				}else{
					
					sb.append(key);
					sb.append("|");
					sb.append(oldMap.get(key));
					sb.append("|");
					sb.append(newMap.get(key));
					sb.append("");
					
				}
				count++;
			}
			
	}
		
		String changes = sb.toString();
		System.out.println("Changes::: "+changes);

	}
	
}

