
/**
 * @author SEmmadi
 *
 */
public class ConvertToJsonFormat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer jsonBuffer= new StringBuffer();
		String REST_AWS_API_KEY = "apikey";
		String REST_AWS_AUTH_KEY ="authkey";
		String REST_AWS_URL= "http//aws";
		String objectID="124";
		String objectName="objName";
		String objectType="";
		String objectSubType=null;
		String activityType="USER";
		String actorId="MODIFIED BY";
		String actorName="MODIFIED BY";
		String actorType="Admin";
		String verb="MODIFIED";
		String level="INFO";
		String summary=null;
		String details="details";
		String timestamp="ts";
		
		jsonBuffer.append("{");
		
		jsonBuffer.append("\"objectid\":\"");
		jsonBuffer.append(objectID);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"objectname\":\"");
		jsonBuffer.append(objectName);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"objecttype\":\"");
		jsonBuffer.append(objectType);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"objectsubtype\":");
		jsonBuffer.append(objectSubType);
		jsonBuffer.append(",");

		jsonBuffer.append("\"activitytype\":\"");
		jsonBuffer.append(activityType);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"actorid\":\"");
		jsonBuffer.append(actorId);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"actorname\":\"");
		jsonBuffer.append(actorName);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"actortype\":\"");
		jsonBuffer.append(actorType);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"verb\":\"");
		jsonBuffer.append(verb);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"level\":\"");
		jsonBuffer.append(level);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"summary\":");
		jsonBuffer.append(summary);
		jsonBuffer.append(",");

		jsonBuffer.append("\"detail\":\"");
		jsonBuffer.append(details);
		jsonBuffer.append("\",");

		jsonBuffer.append("\"timestamp\":\"");
		jsonBuffer.append(timestamp);
		jsonBuffer.append("\"");

		//jsonBuffer.append("\"header\":\"x-api-key:");
		//jsonBuffer.append(REST_AWS_API_KEY);
		//jsonBuffer.append("\",");

		//jsonBuffer.append("\"method\":\"POST\",");

		//jsonBuffer.append("\"contenttype\":\"application/json\"");
		
		/*public static String nullToEmpty(String text) {
		    return text == null ? "" : text;
		}*/
		
		

		jsonBuffer.append("}");
		
		System.out.println("Final JSON :: "+jsonBuffer.toString());

		boolean result=responseAWS();
		//System.out.println("result:: "+result);
		
	}
	public static boolean responseAWS(){
	
	StringBuffer response= new StringBuffer();
	response.append("success");
	response.append("true");
	//response.toString();
	System.out.println("API Response:::"+response);
	System.out.println("Index of "+response.indexOf("success"));
	
	if(response != null &&response.indexOf("success") > -1 && response.indexOf("true") > -1) {
		System.out.println("Success");
		return true;
	} else {
		System.out.println("Failure");
		return false;
	}

	}
}

