
/**
 * @author SEmmadi
 *
 */

interface First{
	public void method();
}
interface Second{
	public void method();
}

class IntTest implements First,Second {

	/* (non-Javadoc)
	 * @see First#method()
	 */
	
	public void method() {
		System.out.println("method");
		
	}
	
}
public class TestE {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		First f= new IntTest();
		f.method();
		System.out.println("Result::");
		
	}

}

