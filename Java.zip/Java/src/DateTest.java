import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author SEmmadi
 *
 */
public class DateTest {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		String d="2019-01-28T10:15:32+00:00";
		//convertToCurrentTimeZone(d);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		//sdf.setTimeZone(TimeZone.getTimeZone("UTC"));   // This line converts the given date into UTC time zone
		Date dateObj = sdf.parse("2019-01-28T10:15:32+00:00");
		String date = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a").format(dateObj);
		System.out.println("DATE:: "+date);
		
		
	}
	
	 public static String utcToLocalTime(String utcDate) throws ParseException{
		 	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			sdf.setTimeZone(TimeZone.getTimeZone("UTC"));   // This line converts the given date into UTC time zone
			Date dateObj = sdf.parse(utcDate);
			String date = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a").format(dateObj);
			
			return date;
		 
	 }
	
	
	/*public static String convertToCurrentTimeZone(String Date) {
        String converted_date = "";
        try {

            DateFormat utcFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            utcFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            Date date = utcFormat.parse(Date);

            DateFormat currentTFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            currentTFormat.setTimeZone(TimeZone.getTimeZone(getCurrentTimeZone()));

            converted_date =  currentTFormat.format(date);
        }catch (Exception e){ e.printStackTrace();
        }
        System.out.println("Converted DAte:: "+converted_date);
        return converted_date;
}

    public static String getCurrentTimeZone(){
        TimeZone tz = Calendar.getInstance().getTimeZone();
        System.out.println(tz.getDisplayName());
        return tz.getID();
}
*/


}

