import java.util.Comparator;

/**
 * @author SEmmadi
 *
 */
interface TitleVest{
	public void method1();
}
public class MethodRef {
	
	public static void orderDetails(){
	 System.out.println("Order Details:::");	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		TitleVest tv= MethodRef::orderDetails;
		tv.method1();
		
		try{
			int c=10,d=0;
			int e;
			//e=c/d;
			
			try{
				int a=10,b=0;
				int k;
				k=a/b;
			}
			catch(Exception e1){
				System.out.println("Inner");
				
			}
			
			if(true){
				System.out.println("if loop after catch");
			}
			
		}catch(Exception e){
			System.out.println("Outer");
		}
		
	}

	
}
