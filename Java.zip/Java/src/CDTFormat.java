
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
/**
 * @author SEmmadi
 *
 */
public class CDTFormat {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {

		
		String res="titlvest\"order\"";
		System.out.println("Resul::"+res);
		
		
		double amount =50000; 
		//double amount =200000; //200000;
		
		System.out.println(String.format("%,.2f", amount));   
		
		
		List<Double> list= new ArrayList<Double>();
		
		list.add(5000d);
		list.add(200000d);
		
		for (Double loanamount : list) {
			System.out.println(String.format("%,.2f", loanamount));
			System.out.println("Loan Amount::"+loanamount);
		}
		

		Calendar currentdate = Calendar.getInstance();
		String d="2019-01-28T10:15:32+00:00";
		//cdtDate(d);
		
		/*DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		TimeZone obj = TimeZone.getTimeZone("CST6CDT");
		formatter.setTimeZone(obj);
		System.out.println("Local:: " +currentdate.getTime());
		System.out.println("CST:: "+ formatter.format(currentdate.getTime()));*/
		
	}
	
	public static Date cdtDate(String date) throws ParseException{
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		TimeZone obj = TimeZone.getTimeZone("CST6CDT");
		formatter.setTimeZone(obj);
		Date dateObj = formatter.parse(date);
		System.out.println("Ddddd "+dateObj);
		String str= new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a").format(dateObj);
		
		//Date dateObj1 = sdf.parse(dateObj);
		//System.out.println("Date!!!"+dateObj1);
		System.out.println("Date!!!"+str);
		
		return dateObj;
		
	}

}

